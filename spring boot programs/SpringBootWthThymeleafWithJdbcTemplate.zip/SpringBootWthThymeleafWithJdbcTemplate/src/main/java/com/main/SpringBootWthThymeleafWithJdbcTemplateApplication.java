package com.main;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBootWthThymeleafWithJdbcTemplateApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringBootWthThymeleafWithJdbcTemplateApplication.class, args);
	}

}
